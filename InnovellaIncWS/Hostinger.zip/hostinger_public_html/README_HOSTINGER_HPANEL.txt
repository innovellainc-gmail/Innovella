INNOVELLA, INC. - HOSTINGER HPANEL UPLOAD INSTRUCTIONS
======================================================

All static production files in this 'hostinger_public_html' folder are pre-rendered and ready to upload directly to your Hostinger Web Hosting account via hPanel File Manager.

Files & Folders to Upload to your Hostinger 'public_html' folder:
-----------------------------------------------------------------
1. index.html          -> Main website homepage and app bundle
2. 404.html            -> Custom enterprise 404 error page
3. 404/                -> 404 directory route index
4. _next/              -> Contains all optimized CSS stylesheets, fonts, and JavaScript chunks
5. .htaccess           -> LiteSpeed / Apache rules for HTTPS redirection, caching & compression
6. robots.txt          -> Search engine crawling instructions
7. sitemap.xml         -> XML sitemap for search engine indexing

STEP-BY-STEP UPLOAD VIA HOSTINGER HPANEL:
-----------------------------------------
1. Log into your Hostinger account at https://hpanel.hostinger.com
2. In your Hosting dashboard, select your website (e.g. innovella.com).
3. Under the "Files" section, click on "File Manager" (Access files of your website).
4. Double-click to open the 'public_html' folder (or domains/yourdomain.com/public_html).
   Note: If there is a default Hostinger 'default.php' or placeholder file, you can safely delete it.
5. In the top toolbar, click the "Upload" icon (arrow pointing up).
6. Upload the files and folders from inside this 'hostinger_public_html' directory directly into 'public_html'.
   
   PRO TIP (FASTEST METHOD):
   - On your computer, select all files inside 'hostinger_public_html' and compress them into a single .zip file.
   - Click "Upload" in Hostinger File Manager and select the .zip file.
   - Right-click the uploaded .zip file inside hPanel File Manager and select "Extract".
   - Set destination to 'public_html' (or current folder).
   - Once extracted, delete the .zip file.

7. Ensure .htaccess is uploaded:
   - Hostinger's LiteSpeed web server automatically reads the .htaccess file for fast gzip compression, caching headers, and automatic HTTPS enforcement.
