'use client';

import React, { useState } from 'react';
import { 
  PhoneCall, 
  Mail, 
  MapPin, 
  Send, 
  CheckCircle2, 
  Clock, 
  Lock
} from 'lucide-react';

interface ContactSectionProps {
  initialVertical?: string;
  initialNeed?: string;
}

export default function ContactSection({ initialVertical = '', initialNeed = '' }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    organization: '',
    phone: '',
    vertical: initialVertical || 'Retail & Omnichannel',
    serviceNeed: initialNeed || 'Systems Integration & Inntermix™ Middleware',
    message: '',
    complianceRequirements: '',
    timeline: 'Within 1-3 Months'
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate enterprise inquiry transmission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <section 
      id="contact" 
      className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Consultation Info */}
          <div className="lg:col-span-5 space-y-6">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md uppercase tracking-wider">
              Executive Engagement
            </span>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Request an Architecture Consultation & Project Scoping Review
            </h2>

            <p className="text-slate-600 text-sm leading-relaxed">
              Connect directly with our senior technology consultants and systems architects. Whether planning a mission-critical integration with <strong className="text-slate-900">Inntermix™</strong>, an enterprise IT audit, or compliance validation, we provide actionable guidance.
            </p>

            {/* Direct Contact Badges */}
            <div className="space-y-4 pt-4 border-t border-slate-200">
              
              <div className="flex items-start gap-3 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0 text-blue-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold uppercase text-slate-500">Headquarters</div>
                  <div className="text-sm font-bold text-slate-900">Costa Mesa, California, USA</div>
                  <div className="text-xs text-slate-500">Serving enterprise clients globally</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0 text-blue-600">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold uppercase text-slate-500">Executive Email</div>
                  <div className="text-sm font-bold text-blue-600">innovella.inc@gmail.com</div>
                  <div className="text-xs text-slate-500">Direct senior partner routing</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0 text-emerald-600">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold uppercase text-slate-500">Response Protocol</div>
                  <div className="text-sm font-bold text-slate-900">Under 1 Business Day</div>
                  <div className="text-xs text-slate-500">Confidentiality & Non-Disclosure (NDA) ready</div>
                </div>
              </div>

            </div>

            {/* NDA & Security Guarantee */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 text-xs text-slate-600 flex items-center gap-2.5 shadow-xs">
              <Lock className="w-4 h-4 text-blue-600 shrink-0" />
              <span>All communications and architecture disclosures are held under strict mutual confidentiality.</span>
            </div>
          </div>

          {/* Right Column: Interactive Consultation Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-md relative">
              
              {submitted ? (
                <div className="py-12 text-center space-y-4 animate-in fade-in duration-300">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 border-2 border-emerald-500 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900">
                    Consultation Request Received
                  </h3>
                  <p className="text-slate-600 text-sm max-w-md mx-auto leading-relaxed">
                    Thank you, <strong className="text-slate-900">{formData.fullName}</strong>. A Senior Solutions Architect from Innovella, Inc. will review your requirements for <strong className="text-blue-600">{formData.organization || 'your organization'}</strong> and reach out within 24 business hours.
                  </p>
                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setSubmitted(false);
                        setFormData({
                          fullName: '',
                          email: '',
                          organization: '',
                          phone: '',
                          vertical: 'Retail & Omnichannel',
                          serviceNeed: 'Systems Integration & Inntermix™ Middleware',
                          message: '',
                          complianceRequirements: '',
                          timeline: 'Within 1-3 Months'
                        });
                      }}
                      className="px-6 py-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Submit Another Inquiry
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="pb-2 border-b border-slate-100 mb-4">
                    <h3 className="text-xl font-bold text-slate-900">
                      Executive Consultation & Project Scoping Form
                    </h3>
                    <p className="text-xs text-slate-500">
                      Please share your enterprise details to connect with the appropriate domain specialist.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Full Name *
                      </label>
                      <input
                        required
                        type="text"
                        placeholder="e.g. Jane Doe"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Corporate Work Email *
                      </label>
                      <input
                        required
                        type="email"
                        placeholder="jane@enterprise.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Organization / Enterprise Name *
                      </label>
                      <input
                        required
                        type="text"
                        placeholder="Company or Agency"
                        value={formData.organization}
                        onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Direct Phone Number (Optional)
                      </label>
                      <input
                        type="tel"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Primary Industry Vertical
                      </label>
                      <select
                        value={formData.vertical}
                        onChange={(e) => setFormData({ ...formData, vertical: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 outline-none transition-colors cursor-pointer"
                      >
                        <option value="Retail & Omnichannel">Retail & Omnichannel (Burlington / Patagonia)</option>
                        <option value="Healthcare & Practice Interoperability">Healthcare & EHR (Pacific Dental)</option>
                        <option value="Life Sciences & Pharma (GxP)">Life Sciences (Allergan / Parexel)</option>
                        <option value="Space Security & Defense">Space Security & Defense (Boeing)</option>
                        <option value="Construction & EPC">Construction & EPC (Fluor)</option>
                        <option value="Insurance & Compliance SaaS">Insurance & Risk (PICS Auditing)</option>
                        <option value="IT, Automation & Cloud">IT & Infrastructure (Axis / Opsware)</option>
                        <option value="Humanitarian & Global NGO">Humanitarian Relief (World Vision)</option>
                        <option value="Other Enterprise Vertical">Other Enterprise Vertical</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Engagement Need
                      </label>
                      <select
                        value={formData.serviceNeed}
                        onChange={(e) => setFormData({ ...formData, serviceNeed: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 outline-none transition-colors cursor-pointer"
                      >
                        <option value="Systems Integration & Inntermix™ Middleware">Systems Integration & Inntermix™</option>
                        <option value="Enterprise IT & Architecture Assessment">Enterprise IT & Architecture Assessment</option>
                        <option value="Custom Enterprise Software Engineering">Custom Enterprise Software Engineering</option>
                        <option value="Regulatory Compliance Validation (FDA/HIPAA/ITAR)">Regulatory Compliance Validation</option>
                        <option value="High-Volume Database & Performance Tuning">Database & Big Data Architecture</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Project Objectives & Technical Scope Overview *
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Describe your current systems landscape, integration goals, legacy challenges, or compliance requirements..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white text-sm text-slate-900 placeholder-slate-400 outline-none resize-none transition-colors"
                    />
                  </div>

                  <button
                    id="submit-consultation-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Transmitting Request...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Executive Consultation Request</span>
                      </>
                    )}
                  </button>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
