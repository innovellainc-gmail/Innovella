'use client';

import React from 'react';
import { 
  Building2, 
  MapPin, 
  ShieldCheck, 
  Zap,
  Globe2
} from 'lucide-react';

export default function AboutHeritage() {
  const pillars = [
    {
      title: 'Founded 2003 in Costa Mesa, CA',
      desc: 'Over 20 years of continuous technical innovation in Southern California, bridging legacy IT architectures with modern cloud ecosystems.',
      icon: MapPin
    },
    {
      title: 'Zero-Defect Engineering Rigor',
      desc: 'Whether building defense-grade telemetry or FDA-validated clinical feeds, our software engineering processes adhere to rigorous standards.',
      icon: ShieldCheck
    },
    {
      title: 'Proprietary Integration IP',
      desc: 'Our Inntermix™ middleware platform and connector patterns eliminate the friction, latency, and fragility common in enterprise data pipelines.',
      icon: Zap
    },
    {
      title: 'Cross-Industry Versatility',
      desc: 'Deep domain fluency across 8 specialized verticals, ensuring our architects understand industry-specific compliance rules on day one.',
      icon: Globe2
    }
  ];

  return (
    <section 
      id="about" 
      className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Story & Ethos */}
          <div className="lg:col-span-7 space-y-6">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md uppercase tracking-wider">
              Company Heritage & Ethos
            </span>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Two Decades of High-Stakes Technical Mastery & Systems Craftsmanship
            </h2>

            <p className="text-slate-600 text-base leading-relaxed">
              Established in 2003 in Costa Mesa, California, <strong className="text-slate-900 font-semibold">Innovella, Inc.</strong> was founded on a singular engineering conviction: enterprise software and data integration must be resilient, deterministic, and built to withstand real-world operational scale.
            </p>

            <p className="text-slate-600 text-base leading-relaxed">
              Over two decades, we have avoided the bloated overhead of conventional agency models in favor of elite, battle-tested senior architects who work directly alongside client leadership. From Fortune 500 retailers like <strong className="text-slate-900 font-semibold">Burlington Coat Factory</strong> and <strong className="text-slate-900 font-semibold">Patagonia</strong> to aerospace giants like <strong className="text-slate-900 font-semibold">Boeing</strong> and global CROs like <strong className="text-slate-900 font-semibold">Parexel</strong>, our clients depend on Innovella for their most critical technical endeavors.
            </p>

            {/* Quick Stats Banner */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-200">
              <div>
                <div className="text-2xl font-extrabold text-slate-900 font-sans">
                  2003
                </div>
                <div className="text-xs text-slate-500 font-medium">
                  Year Established
                </div>
              </div>

              <div>
                <div className="text-2xl font-extrabold text-blue-600 font-sans">
                  Costa Mesa
                </div>
                <div className="text-xs text-slate-500 font-medium">
                  California HQ
                </div>
              </div>

              <div>
                <div className="text-2xl font-extrabold text-slate-900 font-sans">
                  100%
                </div>
                <div className="text-xs text-slate-500 font-medium">
                  Senior Architect Staffed
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: 4 Pillar Cards */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {pillars.map((pillar, idx) => {
              const IconComp = pillar.icon;
              return (
                <div 
                  key={idx}
                  className="p-5 rounded-xl bg-white border border-slate-200 shadow-sm flex items-start gap-4 hover:border-blue-300 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0 text-blue-600 mt-1">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm mb-1">
                      {pillar.title}
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed font-normal">
                      {pillar.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
}
