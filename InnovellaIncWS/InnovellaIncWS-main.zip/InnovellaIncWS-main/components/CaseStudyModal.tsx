'use client';

import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Cpu, 
  Quote, 
  ArrowRight,
  ShieldCheck,
  Building2,
  Calendar,
  Layers
} from 'lucide-react';
import { ClientRecord } from '../data/clientsData';

interface CaseStudyModalProps {
  client: ClientRecord | null;
  onClose: () => void;
}

export default function CaseStudyModal({ client, onClose }: CaseStudyModalProps) {
  if (!client) return null;

  return (
    <div 
      id="case-study-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id={`case-study-modal-${client.id}`}
        className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden my-8 text-slate-900 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-blue-100 text-blue-700">
              {client.verticalLabel}
            </span>
            <span className="text-xs text-slate-500 font-semibold">
              Client Engagement Profile &bull; 2026 Modernized Audit
            </span>
          </div>
          <button
            id="close-case-study-modal-btn"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close case study details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 sm:p-8 space-y-8 max-h-[80vh] overflow-y-auto">
          
          {/* Client Title and Tagline */}
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
              {client.name}
            </h2>
            <p className="text-lg text-blue-600 font-bold">
              {client.tagline}
            </p>
            <p className="mt-3 text-slate-600 text-base leading-relaxed">
              {client.summary}
            </p>
          </div>

          {/* Impact Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {client.impactMetrics.map((metric, idx) => (
              <div 
                key={idx}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center"
              >
                <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 font-sans mb-1">
                  {metric.value}
                </div>
                <div className="text-xs font-medium text-slate-500">
                  {metric.label}
                </div>
              </div>
            ))}
          </div>

          {/* Challenge & Solution Architecture Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* The Enterprise Challenge */}
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm mb-3">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span>The Operational Challenge</span>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed font-normal">
                {client.challenge}
              </p>
            </div>

            {/* Innovella's Solution Architecture */}
            <div className="p-5 rounded-xl bg-blue-50/50 border border-blue-200/80">
              <div className="flex items-center gap-2 text-blue-900 font-bold text-sm mb-3">
                <span className="w-2 h-2 rounded-full bg-blue-600" />
                <span>Innovella Engineering Solution</span>
              </div>
              <p className="text-slate-700 text-sm leading-relaxed font-normal">
                {client.solution}
              </p>
            </div>

          </div>

          {/* Key Deliverables & Measurable Outcomes */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-200">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Verified Deliverables & Key Operational Outcomes</span>
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {client.keyOutcomes.map((outcome, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-2 shrink-0" />
                  <span>{outcome}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Technologies & Architectural Stack */}
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-600" />
              <span>Architectural Stack & Protocols</span>
            </h3>
            <div className="flex flex-wrap gap-2">
              {client.techStack.map((tech, idx) => (
                <span 
                  key={idx}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 border border-slate-200 text-slate-700 text-xs font-medium"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Testimonial / Stakeholder Highlight if available */}
          {client.quote && (
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 relative">
              <Quote className="w-6 h-6 text-blue-200 absolute top-4 right-4" />
              <p className="italic text-slate-700 text-sm leading-relaxed mb-3">
                &ldquo;{client.quote.text}&rdquo;
              </p>
              <div className="flex items-center gap-2 text-xs">
                <span className="font-bold text-slate-900">{client.quote.author}</span>
                <span className="text-slate-400">&bull;</span>
                <span className="text-slate-500">{client.quote.title}</span>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-slate-200 bg-slate-50">
          <span className="text-xs text-slate-500 font-medium">
            Need similar architecture for your organization?
          </span>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold transition-colors"
            >
              Close
            </button>
            <a
              href="#contact"
              onClick={onClose}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider shadow-sm transition-colors"
            >
              <span>Consult Our Architects</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
