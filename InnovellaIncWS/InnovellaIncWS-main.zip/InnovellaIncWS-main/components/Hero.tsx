'use client';

import React from 'react';
import { 
  ShieldCheck, 
  ArrowRight, 
  Layers, 
  Cpu, 
  CheckCircle2, 
  ExternalLink,
  FileSpreadsheet,
  Activity,
  ShoppingBag,
  FlaskConical,
  HardHat,
  HeartHandshake
} from 'lucide-react';

interface HeroProps {
  onSelectVertical: (verticalId: string) => void;
}

export default function Hero({ onSelectVertical }: HeroProps) {
  const quickPills = [
    { id: 'defense', label: 'Space & Defense', client: 'Boeing', icon: ShieldCheck },
    { id: 'life-sciences', label: 'Life Sciences', client: 'Allergan & Parexel', icon: FlaskConical },
    { id: 'retail', label: 'Retail Omnichannel', client: 'Burlington & Patagonia', icon: ShoppingBag },
    { id: 'healthcare', label: 'Healthcare & EHR', client: 'Pacific Dental Services', icon: Activity },
    { id: 'construction', label: 'Construction & EPC', client: 'Fluor', icon: HardHat },
    { id: 'humanitarian', label: 'Humanitarian Relief', client: 'World Vision', icon: HeartHandshake },
    { id: 'it', label: 'IT & Infrastructure', client: 'Axis & Opsware', icon: Cpu },
  ];

  return (
    <section 
      id="hero-section"
      className="relative pt-28 pb-16 md:pt-36 md:pb-24 bg-slate-50 border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Eyebrow Badge */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
          <span className="inline-block px-3.5 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md uppercase tracking-wider">
            Enterprise Consulting Experts &bull; Est. 2003
          </span>
          <span className="inline-block px-3 py-1 bg-white border border-slate-200 text-slate-600 text-xs font-semibold rounded-md">
            Costa Mesa, CA, USA
          </span>
        </div>

        {/* Main Headline */}
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12] mb-5">
            Scaling Global Leaders <br className="hidden sm:inline" />
            Through <span className="text-blue-600">Precision Innovation.</span>
          </h1>

          <p className="text-base sm:text-lg md:text-xl text-slate-600 font-normal leading-relaxed max-w-3xl mx-auto mb-8">
            Since 2003, Innovella, Inc. has engineered high-precision technology consulting, systems integration, and resilient data architectures for industry titans across <strong className="text-slate-900 font-semibold">Retail</strong>, <strong className="text-slate-900 font-semibold">Healthcare</strong>, <strong className="text-slate-900 font-semibold">Life Sciences</strong>, <strong className="text-slate-900 font-semibold">Space & Defense</strong>, and <strong className="text-slate-900 font-semibold">Global NGOs</strong>.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <a
              id="hero-cta-clients"
              href="#clients"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm hover:shadow transition-all duration-200"
            >
              <span>Explore Client Track Record</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <a
              id="hero-cta-analysis"
              href="#analysis"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-semibold text-sm transition-all duration-200 shadow-sm"
            >
              <FileSpreadsheet className="w-4 h-4 text-blue-600" />
              <span>Senior Business Analyst Report</span>
            </a>
          </div>

          {/* Quick Vertical Switcher Bar */}
          <div className="pt-6 border-t border-slate-200">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 text-center">
              Featured Client Engagements by Industry Vertical
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 max-w-5xl mx-auto">
              {quickPills.map((pill) => {
                const IconComponent = pill.icon;
                return (
                  <button
                    key={pill.id}
                    id={`hero-pill-${pill.id}`}
                    type="button"
                    onClick={() => {
                      onSelectVertical(pill.id);
                      const el = document.getElementById('clients');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-700 hover:text-blue-700 text-xs font-medium transition-all duration-150 cursor-pointer shadow-sm group"
                  >
                    <IconComponent className="w-3.5 h-3.5 text-blue-600 group-hover:text-blue-700" />
                    <span className="font-bold text-slate-900">{pill.label}:</span>
                    <span className="text-slate-600 group-hover:text-slate-900">{pill.client}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Enterprise Key Performance Stats Matrix */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-5xl mx-auto">
          
          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-sm text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-sans tracking-tight mb-1">
              20+ Years
            </div>
            <div className="text-xs font-medium text-slate-500">
              Enterprise Track Record (Est. 2003)
            </div>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-sm text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 font-sans tracking-tight mb-1">
              11 Marquee
            </div>
            <div className="text-xs font-medium text-slate-500">
              Enterprise Client Deployments
            </div>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-sm text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-sans tracking-tight mb-1">
              8 Verticals
            </div>
            <div className="text-xs font-medium text-slate-500">
              From Defense to Life Sciences
            </div>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-sm text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 font-sans tracking-tight mb-1">
              99.995%
            </div>
            <div className="text-xs font-medium text-slate-500">
              Mission-Critical Reliability
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
