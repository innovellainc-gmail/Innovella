'use client';

import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  CheckCircle2, 
  ChevronDown,
  ChevronUp,
  FileCheck,
  Calendar
} from 'lucide-react';
import { BUSINESS_ANALYSIS_REPORT } from '../data/businessAnalysisData';

export default function BusinessAnalysisReport() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  return (
    <section 
      id="analysis" 
      className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md mb-3 uppercase tracking-wider">
            Senior Business Analyst & Senior Developer Review
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Strategic Website Audit & Architecture Modernization Report
          </h2>
          <p className="mt-3 text-slate-600 text-base leading-relaxed">
            Formal architectural review and strategic positioning analysis of the original <code className="text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 text-xs font-mono">innovella.com</code> web presence, detailing our systematic 2026 overhaul.
          </p>
        </div>

        {/* Executive Summary Card */}
        <div className="p-6 sm:p-8 rounded-xl bg-white border border-slate-200 shadow-sm mb-10">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
                <FileCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">Executive Briefing & Synthesis</h3>
                <p className="text-xs text-slate-500">Innovella, Inc. Technical Audit &bull; 2026 Revision</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-700 bg-blue-50 px-3 py-1.5 rounded-md border border-blue-200">
              <Calendar className="w-3.5 h-3.5" />
              <span>{BUSINESS_ANALYSIS_REPORT.date}</span>
            </div>
          </div>

          <p className="text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line font-normal">
            {BUSINESS_ANALYSIS_REPORT.executiveSummary}
          </p>
        </div>

        {/* Audit Pillars Accordion */}
        <div className="space-y-4 mb-12">
          {BUSINESS_ANALYSIS_REPORT.auditSections.map((section, idx) => {
            const isExpanded = expandedIndex === idx;
            return (
              <div 
                key={idx}
                className="rounded-xl bg-white border border-slate-200 overflow-hidden shadow-xs transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className="w-full flex items-center justify-between p-6 text-left hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                    <span className="px-2.5 py-1 rounded text-xs font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200 self-start">
                      {section.badge}
                    </span>
                    <h4 className="text-base sm:text-lg font-bold text-slate-900">
                      {section.title}
                    </h4>
                  </div>
                  <div className="text-slate-400 shrink-0 ml-2">
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-slate-700" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-6 pb-6 pt-2 border-t border-slate-100 space-y-4">
                    <p className="text-sm text-slate-600">
                      {section.summary}
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                      {section.points.map((pt, pIdx) => (
                        <div 
                           key={pIdx}
                           className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900 text-sm">
                              {pt.label}
                            </span>
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
                              {pt.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            {pt.detail}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* 2026 Standards Validation Matrix */}
        <div className="p-6 sm:p-8 rounded-xl bg-white border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-blue-600" />
            <span>2026 Enterprise Quality & Compliance Verification Checklist</span>
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-blue-700 font-bold block mb-1">✓ 100% Mobile Fluid</span>
              <span className="text-slate-600">Optimized across iOS Safari, Android Chrome, tablets, and desktop workstations.</span>
            </div>

            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-blue-700 font-bold block mb-1">✓ Zero Grammar Errors</span>
              <span className="text-slate-600">Audited enterprise copy with precise industry terminology for defense, FDA, and healthcare.</span>
            </div>

            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-blue-700 font-bold block mb-1">✓ 2026 Copyright Standard</span>
              <span className="text-slate-600">All legal notices, footers, and metadata reflect 2003–2026 active registration.</span>
            </div>

            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-blue-700 font-bold block mb-1">✓ 11 Marquee Engagements</span>
              <span className="text-slate-600">Burlington, Patagonia, Boeing, Fluor, Allergan, Parexel, PICS, PDS, Opsware, Axis, World Vision.</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
