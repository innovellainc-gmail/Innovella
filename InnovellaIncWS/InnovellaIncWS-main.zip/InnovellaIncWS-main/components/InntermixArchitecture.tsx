'use client';

import React, { useState } from 'react';
import { 
  Network, 
  Layers, 
  ArrowRight, 
  CheckCircle2, 
  Server, 
  Database, 
  ShieldCheck, 
  Activity, 
  Lock, 
  Zap,
  Repeat
} from 'lucide-react';

export default function InntermixArchitecture() {
  const [activePreset, setActivePreset] = useState<'retail' | 'healthcare' | 'lifesciences' | 'defense'>('retail');

  const presets = {
    retail: {
      title: 'Retail Real-Time Omnichannel Sync',
      clientExample: 'Burlington Coat Factory & Patagonia',
      source: 'Legacy IBM AS/400 & Distribution ERPs',
      inntermixRole: 'High-Concurrency Ingestion & Stock Reconciliation Queue',
      destination: '1,000+ POS Terminals, E-Commerce API & Warehouse Nodes',
      latency: '< 60 seconds',
      throughput: '45,000,000+ SKU Transactions / Day',
      security: 'TLS 1.3 + Message Authentication Codes'
    },
    healthcare: {
      title: 'HIPAA Multi-Clinic EHR Interoperability',
      clientExample: 'Pacific Dental Services (800+ Clinics)',
      source: 'Disparate On-Premise Practice Management Software',
      inntermixRole: 'HL7/FHIR Normalization & Cryptographic HIPAA Audit Pipeline',
      destination: 'Central Electronic Health Record & Real-Time Insurance Gateways',
      latency: 'Sub-second real-time adjudication',
      throughput: '5,000,000+ Annual Patient Records',
      security: 'End-to-End AES-256 + HIPAA/HITECH Audit Trails'
    },
    lifesciences: {
      title: 'FDA 21 CFR Part 11 Validated Clinical Data Feed',
      clientExample: 'Allergan & Parexel Global Trials',
      source: 'Heterogeneous Clinical Trial Laboratories & Research Hospitals',
      inntermixRole: 'CDISC/SDTM Harmonization & Immutable Electronic Signature Audit',
      destination: 'FDA / EMA Regulatory Dossiers & Biostatistical Analytics',
      latency: 'Automated Real-Time Ingestion',
      throughput: '2,500+ Global Research Site Feeds',
      security: 'GAMP 5 CSV Validated & Tamper-Evident Signatures'
    },
    defense: {
      title: 'ITAR & Defense-Grade Air-Gapped Telemetry',
      clientExample: 'Boeing & Aerospace Programs',
      source: 'Air-Gapped Engineering Workstations & Avionics Test Benches',
      inntermixRole: 'Deterministic Store-and-Forward & Zero-Trust Verification',
      destination: 'Secure Defense Data Hubs & Real-Time Telemetry Analyzers',
      latency: 'Deterministic Microsecond Response',
      throughput: 'Zero Data Loss Air-Gapped Transmission',
      security: 'ITAR / NIST 800-171 / Defense Zero-Trust'
    }
  };

  const current = presets[activePreset];

  return (
    <section 
      id="inntermix" 
      className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200 scroll-mt-16 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md mb-3 uppercase tracking-wider">
            Proprietary Integration Framework
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Inntermix™ Enterprise Data Interoperability Engine
          </h2>
          <p className="mt-3 text-slate-600 text-base leading-relaxed">
            First engineered by Innovella to dismantle stubborn enterprise data silos, the Inntermix framework bridges legacy mainframe architectures with modern cloud-native systems without costly total-system replacements.
          </p>
        </div>

        {/* Interactive Scenario Presets */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          <button
            type="button"
            onClick={() => setActivePreset('retail')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activePreset === 'retail'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            Retail Omnichannel (Burlington & Patagonia)
          </button>
          <button
            type="button"
            onClick={() => setActivePreset('healthcare')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activePreset === 'healthcare'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            Healthcare EHR / HIPAA (Pacific Dental)
          </button>
          <button
            type="button"
            onClick={() => setActivePreset('lifesciences')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activePreset === 'lifesciences'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            Life Sciences 21 CFR Part 11 (Allergan & Parexel)
          </button>
          <button
            type="button"
            onClick={() => setActivePreset('defense')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activePreset === 'defense'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            Defense & ITAR (Boeing)
          </button>
        </div>

        {/* 3-Stage Visual Pipeline Architecture Diagram */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
          
          {/* Stage 1: Legacy / Source Systems */}
          <div className="p-6 rounded-xl bg-white border border-slate-200 shadow-sm relative flex flex-col justify-between">
            <div className="absolute -top-3 left-6 px-2.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px] font-bold text-slate-600 uppercase">
              Stage 1: Ingestion
            </div>
            
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Heterogeneous Sources</h4>
                  <p className="text-xs text-slate-500">Legacy Core & Edge Systems</p>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Active Scenario Source:
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {current.source}
                </div>
              </div>

              <ul className="space-y-2 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Mainframes (AS/400), ERPs (SAP/Oracle), Legacy RDBMS</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Bandwidth-constrained satellite & field uplinks</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Disparate clinical and industrial telemetry streams</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 text-right hidden lg:block">
              <span className="text-xs text-blue-600 font-semibold flex items-center justify-end gap-1">
                <span>Streaming Ingestion</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>

          {/* Stage 2: Inntermix™ Core Integration Mesh */}
          <div className="p-6 rounded-xl bg-blue-50/40 border-2 border-blue-500/50 shadow-md relative flex flex-col justify-between">
            <div className="absolute -top-3 left-6 px-2.5 py-0.5 rounded bg-blue-600 text-white text-[10px] font-bold uppercase shadow-xs">
              Stage 2: Inntermix™ Core Engine
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Transformation & Brokerage</h4>
                  <p className="text-xs text-blue-600 font-semibold">Innovella Middleware Layer</p>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-white border border-blue-200">
                <div className="text-[11px] font-bold text-blue-700 uppercase tracking-wider mb-1">
                  Transformation Matrix:
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {current.inntermixRole}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Latency</span>
                  <span className="font-bold text-blue-600">{current.latency}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Throughput</span>
                  <span className="font-bold text-slate-900">{current.throughput}</span>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-xs">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Security Standard</span>
                <span className="font-medium text-slate-800 flex items-center gap-1 mt-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{current.security}</span>
                </span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-blue-200/60 text-right hidden lg:block">
              <span className="text-xs text-blue-600 font-semibold flex items-center justify-end gap-1">
                <span>Verified Egress</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>

          {/* Stage 3: Modern Destinations & Cloud Ecosystems */}
          <div className="p-6 rounded-xl bg-white border border-slate-200 shadow-sm relative flex flex-col justify-between">
            <div className="absolute -top-3 left-6 px-2.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px] font-bold text-slate-600 uppercase">
              Stage 3: Enterprise Delivery
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Modern Destinations</h4>
                  <p className="text-xs text-slate-500">Microservices, Analytics & Apps</p>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Verified Destination:
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {current.destination}
                </div>
              </div>

              <ul className="space-y-2 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Real-time executive dashboards and mobile POS</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Cloud data lakes (Snowflake, BigQuery, AWS, Azure)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Regulatory filing and compliance audit engines</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 text-right">
              <span className="text-xs text-slate-500 font-medium">
                99.995% Delivery Guarantee
              </span>
            </div>
          </div>

        </div>

        {/* Bottom Callout */}
        <div className="mt-10 p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0">
              <Repeat className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-xs sm:text-sm text-slate-700">
              Innovella engineers custom connectors for proprietary protocols, legacy mainframes, and modern APIs with zero vendor lock-in.
            </p>
          </div>
          <a
            href="#contact"
            className="shrink-0 px-4 py-2 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
          >
            Discuss Interoperability Architecture &rarr;
          </a>
        </div>

      </div>
    </section>
  );
}
