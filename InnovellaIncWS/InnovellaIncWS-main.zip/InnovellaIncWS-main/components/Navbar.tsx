'use client';

import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Menu, 
  X, 
  ChevronRight, 
  ShieldCheck, 
  Layers, 
  Briefcase, 
  FileText, 
  PhoneCall,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  onOpenAnalysisModal?: () => void;
  onOpenEstimatorModal?: () => void;
}

export default function Navbar({ onOpenAnalysisModal, onOpenEstimatorModal }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Verticals & Clients', href: '#clients' },
    { label: 'Core Capabilities', href: '#services' },
    { label: 'Inntermix™ Platform', href: '#inntermix' },
    { label: 'About & Heritage', href: '#about' },
    { label: 'Strategic Analysis', href: '#analysis' },
    { label: 'Scope Estimator', href: '#estimator' },
  ];

  return (
    <header 
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm py-3.5' 
          : 'bg-white/80 backdrop-blur-sm border-b border-slate-100 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Brand Logo */}
          <a 
            id="nav-brand-logo"
            href="#" 
            className="flex items-center gap-3 group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-black text-xl shadow-sm group-hover:bg-blue-700 transition-colors">
              I
            </div>
            <div className="flex flex-col">
              <div className="flex items-center">
                <span className="font-extrabold text-slate-900 tracking-tight text-xl font-sans">
                  INNOVELLA<span className="text-blue-600">, INC.</span>
                </span>
              </div>
              <span className="text-[10px] text-slate-500 font-semibold tracking-widest uppercase -mt-0.5">
                Enterprise Consulting &bull; Est. 2003
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs font-semibold uppercase tracking-wider text-slate-600 hover:text-blue-600 transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action CTAs */}
          <div className="hidden md:flex items-center gap-3">
            <a
              id="nav-cta-contact"
              href="#contact"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider shadow-sm transition-all duration-200"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Partner With Us</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            id="mobile-menu-toggle"
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div 
          id="mobile-navigation-drawer"
          className="lg:hidden border-b border-slate-200 bg-white/98 backdrop-blur-xl px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-4 duration-200 shadow-xl"
        >
          <div className="space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-semibold uppercase tracking-wider text-slate-700 hover:bg-slate-100 hover:text-blue-600 transition-colors"
              >
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-200 space-y-2">
            <a
              id="mobile-cta-consult"
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 w-full py-3 rounded-full bg-slate-900 text-white font-bold text-xs uppercase tracking-wider shadow-sm"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Request Executive Consultation</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
