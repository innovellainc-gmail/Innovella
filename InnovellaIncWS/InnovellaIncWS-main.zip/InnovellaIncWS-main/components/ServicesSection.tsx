'use client';

import React, { useState } from 'react';
import { 
  Network, 
  ShieldCheck, 
  Code2, 
  FileCheck2, 
  Lock, 
  Database, 
  ArrowRight, 
  Check, 
  Layers
} from 'lucide-react';
import { SERVICES_DATA, ServiceCapability } from '../data/servicesData';

export default function ServicesSection() {
  const [selectedService, setSelectedService] = useState<ServiceCapability>(SERVICES_DATA[0]);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Network': return Network;
      case 'ShieldCheck': return ShieldCheck;
      case 'Code2': return Code2;
      case 'FileCheck2': return FileCheck2;
      case 'Lock': return Lock;
      case 'Database': return Database;
      default: return Layers;
    }
  };

  return (
    <section 
      id="services" 
      className="py-20 bg-white text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md mb-3 uppercase tracking-wider">
            Enterprise Consulting Capabilities
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Comprehensive Enterprise Services & Specialized Technical Domains
          </h2>
          <p className="mt-3 text-slate-600 text-base leading-relaxed">
            From comprehensive IT architecture audits to high-throughput data integration and regulatory compliance validation, Innovella provides specialized technical depth for high-stakes environments.
          </p>
        </div>

        {/* Services Master Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {SERVICES_DATA.map((service) => {
            const IconComp = getServiceIcon(service.iconName);
            const isSelected = selectedService.id === service.id;

            return (
              <div
                key={service.id}
                id={`service-card-${service.id}`}
                onClick={() => setSelectedService(service)}
                className={`p-6 rounded-xl border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-blue-600 shadow-lg ring-1 ring-blue-600'
                    : 'bg-slate-50/70 hover:bg-white hover:shadow-xl border-slate-200 hover:border-blue-200'
                }`}
              >
                <div>
                  {/* Category & Icon */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold text-blue-600 uppercase tracking-tight">
                      {service.category}
                    </span>
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      isSelected ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-blue-600 shadow-xs'
                    }`}>
                      <IconComp className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-slate-900 mb-2">
                    {service.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-600 leading-relaxed mb-4 font-normal">
                    {service.description}
                  </p>
                </div>

                {/* Deliverables snippet */}
                <div>
                  <div className="pt-4 border-t border-slate-200/80 space-y-1.5 mb-4">
                    {service.keyDeliverables.slice(0, 2).map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{item}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-xs pt-2">
                    <span className="text-slate-500 font-medium">
                      {service.technologies.length} Stack Components
                    </span>
                    <span className="font-bold text-blue-600 flex items-center gap-1 hover:text-blue-800">
                      <span>View Breakdown</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Service Detail Panel */}
        <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm">
          <div className="flex flex-col lg:flex-row gap-8 items-start justify-between">
            
            <div className="max-w-2xl space-y-4">
              <span className="inline-block px-3 py-1 rounded-md bg-blue-100 text-blue-700 text-xs font-bold uppercase tracking-wider">
                Selected Domain: {selectedService.category}
              </span>
              
              <h3 className="text-2xl font-bold text-slate-900">
                {selectedService.title}
              </h3>

              <p className="text-slate-600 text-sm leading-relaxed">
                {selectedService.description}
              </p>

              <div className="p-4 rounded-xl bg-white border border-slate-200 text-sm">
                <span className="text-blue-700 font-bold block mb-1">
                  Enterprise Strategic Value:
                </span>
                <span className="text-slate-700">
                  {selectedService.enterpriseBenefits}
                </span>
              </div>
            </div>

            <div className="w-full lg:max-w-md space-y-6">
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
                  Core Deliverables & Outputs
                </h4>
                <ul className="space-y-2.5">
                  {selectedService.keyDeliverables.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                  Key Technologies & Frameworks
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedService.technologies.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-md bg-white text-xs font-medium text-slate-700 border border-slate-200"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
