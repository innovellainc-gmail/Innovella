'use client';

import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpRight, 
  CheckCircle2, 
  Layers, 
  Building2, 
  ShoppingBag, 
  Activity, 
  Cpu, 
  FlaskConical, 
  ShieldCheck, 
  ShieldAlert, 
  HardHat, 
  HeartHandshake, 
  Server,
  Sparkles,
  ExternalLink,
  ChevronRight,
  SlidersHorizontal,
  Table as TableIcon,
  LayoutGrid
} from 'lucide-react';
import { CLIENTS_DATA, VERTICAL_TABS, ClientRecord } from '../data/clientsData';
import CaseStudyModal from './CaseStudyModal';

interface ClientShowcaseProps {
  activeVertical: string;
  onSelectVertical: (verticalId: string) => void;
}

export default function ClientShowcase({ activeVertical, onSelectVertical }: ClientShowcaseProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState<ClientRecord | null>(null);
  const [viewLayout, setViewLayout] = useState<'grid' | 'table'>('grid');

  const filteredClients = useMemo(() => {
    return CLIENTS_DATA.filter((client) => {
      const matchesVertical = activeVertical === 'all' || client.vertical === activeVertical;
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch = !query || 
        client.name.toLowerCase().includes(query) ||
        client.verticalLabel.toLowerCase().includes(query) ||
        client.tagline.toLowerCase().includes(query) ||
        client.summary.toLowerCase().includes(query) ||
        client.techStack.some((t) => t.toLowerCase().includes(query));

      return matchesVertical && matchesSearch;
    });
  }, [activeVertical, searchQuery]);

  const getVerticalIcon = (vertical: string) => {
    switch (vertical) {
      case 'retail': return ShoppingBag;
      case 'healthcare': return Activity;
      case 'it': return Cpu;
      case 'life-sciences': return FlaskConical;
      case 'insurance': return ShieldCheck;
      case 'defense': return ShieldAlert;
      case 'construction': return HardHat;
      case 'humanitarian': return HeartHandshake;
      default: return Building2;
    }
  };

  return (
    <section 
      id="clients" 
      className="py-20 bg-white text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md mb-3 uppercase tracking-wider">
              Proven Enterprise Track Record
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Featured Client Engagements & Vertical Portfolios
            </h2>
            <p className="mt-3 text-slate-600 text-base leading-relaxed">
              Explore how Innovella, Inc. has engineered mission-critical software, solved complex interoperability challenges, and delivered enduring value across 8 key industry verticals.
            </p>
          </div>

          {/* Quick View Mode Toggle */}
          <div className="flex items-center gap-1 self-start md:self-auto bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setViewLayout('grid')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors ${
                viewLayout === 'grid' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              aria-label="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Card Grid</span>
            </button>
            <button
              type="button"
              onClick={() => setViewLayout('table')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors ${
                viewLayout === 'table' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              aria-label="Table View"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Executive Matrix</span>
            </button>
          </div>
        </div>

        {/* Filter Controls: Search Input & Vertical Tabs */}
        <div className="space-y-4 mb-10">
          
          {/* Search Bar */}
          <div className="relative max-w-xl">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="clients-search-input"
              type="text"
              placeholder="Search by client, vertical (e.g. Retail, Defense, Life Sciences), or tech..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white focus:ring-1 focus:ring-blue-600 text-sm text-slate-900 placeholder-slate-400 transition-all outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-900 bg-slate-200 px-2 py-0.5 rounded"
              >
                Clear
              </button>
            )}
          </div>

          {/* Vertical Tabs Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {VERTICAL_TABS.map((tab) => {
              const isActive = activeVertical === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab-${tab.id}`}
                  type="button"
                  onClick={() => onSelectVertical(tab.id)}
                  className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-150 flex items-center gap-2 cursor-pointer ${
                    isActive 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-white/25 text-white' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>

        </div>

        {/* Results Counter */}
        <div className="flex items-center justify-between text-xs text-slate-500 mb-6">
          <span>
            Showing <strong className="text-slate-900">{filteredClients.length}</strong> verified enterprise client {filteredClients.length === 1 ? 'record' : 'records'}
          </span>
          {activeVertical !== 'all' && (
            <button
              type="button"
              onClick={() => onSelectVertical('all')}
              className="text-blue-600 font-semibold hover:underline text-xs"
            >
              Reset vertical filter
            </button>
          )}
        </div>

        {/* Card Grid View */}
        {viewLayout === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClients.map((client) => {
              const VerticalIcon = getVerticalIcon(client.vertical);

              return (
                <div
                  key={client.id}
                  id={`client-card-${client.id}`}
                  className="group relative flex flex-col justify-between p-6 border border-slate-200/80 rounded-xl bg-slate-50/50 hover:bg-white hover:shadow-xl hover:border-blue-200 transition-all duration-300"
                >
                  {/* Card Top */}
                  <div>
                    {/* Vertical Badge & Category Icon */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <p className="text-xs font-black text-blue-600 uppercase tracking-tighter flex items-center gap-1.5">
                        <VerticalIcon className="w-3.5 h-3.5" />
                        <span>{client.verticalLabel}</span>
                      </p>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                        Verified
                      </span>
                    </div>

                    {/* Client Name */}
                    <h3 className="text-xl font-bold text-slate-900 group-hover:text-blue-700 transition-colors mb-1">
                      {client.name}
                    </h3>

                    {/* Tagline */}
                    <p className="text-xs font-semibold text-slate-500 mb-3 line-clamp-1">
                      {client.tagline}
                    </p>

                    {/* Summary Description */}
                    <p className="text-sm text-slate-600 leading-relaxed mb-5 line-clamp-3 font-normal">
                      {client.summary}
                    </p>

                    {/* Primary Highlight Metrics */}
                    <div className="grid grid-cols-2 gap-2 p-3 rounded-lg bg-white border border-slate-200/80 mb-5 shadow-xs">
                      {client.impactMetrics.slice(0, 2).map((metric, idx) => (
                        <div key={idx} className="text-left">
                          <div className="text-lg font-extrabold text-blue-600">
                            {metric.value}
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            {metric.label}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Tech Stack Chips */}
                    <div className="flex flex-wrap gap-1.5 mb-5">
                      {client.techStack.slice(0, 3).map((tech, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-slate-100 text-[11px] text-slate-600 font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                      {client.techStack.length > 3 && (
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-[11px] text-slate-500">
                          +{client.techStack.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Bottom / Action CTA */}
                  <div className="pt-4 border-t border-slate-200/80 flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-medium">
                      Enterprise Profile
                    </span>
                    <button
                      id={`btn-view-case-study-${client.id}`}
                      type="button"
                      onClick={() => setSelectedClient(client)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 group-hover:translate-x-0.5 transition-all cursor-pointer"
                    >
                      <span>Case Study</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Executive Table / Matrix View */}
        {viewLayout === 'table' && (
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
            <table className="w-full text-left text-sm text-slate-700">
              <thead className="bg-slate-50 text-xs uppercase font-bold text-slate-500 border-b border-slate-200">
                <tr>
                  <th scope="col" className="px-6 py-4">Client Enterprise</th>
                  <th scope="col" className="px-6 py-4">Industry Vertical</th>
                  <th scope="col" className="px-6 py-4">Core Solution Scope</th>
                  <th scope="col" className="px-6 py-4">Key Verified Outcome</th>
                  <th scope="col" className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredClients.map((client) => {
                  const VerticalIcon = getVerticalIcon(client.vertical);
                  return (
                    <tr 
                      key={client.id}
                      className="hover:bg-slate-50 transition-colors group"
                    >
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                          {client.name}
                        </div>
                        <div className="text-xs text-slate-500">
                          {client.tagline}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
                          <VerticalIcon className="w-3.5 h-3.5" />
                          <span>{client.verticalLabel}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 max-w-xs">
                        <p className="text-xs text-slate-600 line-clamp-2">
                          {client.summary}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-block px-2.5 py-1 rounded-md bg-slate-100 text-slate-800 text-xs font-bold">
                          {client.impactMetrics[0].value} {client.impactMetrics[0].label}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setSelectedClient(client)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-white text-xs font-bold transition-colors"
                        >
                          <span>Case Study</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Empty State */}
        {filteredClients.length === 0 && (
          <div className="text-center py-16 px-4 rounded-xl bg-slate-50 border border-slate-200">
            <p className="text-lg font-bold text-slate-900 mb-2">No matching client engagements found</p>
            <p className="text-sm text-slate-500 mb-4">Try adjusting your search query or selecting another industry vertical tab.</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                onSelectVertical('all');
              }}
              className="px-4 py-2 rounded-full bg-slate-900 text-white text-xs font-bold uppercase tracking-wider"
            >
              Reset All Filters
            </button>
          </div>
        )}

      </div>

      {/* Case Study Deep Dive Modal */}
      <CaseStudyModal
        client={selectedClient}
        onClose={() => setSelectedClient(null)}
      />
    </section>
  );
}
