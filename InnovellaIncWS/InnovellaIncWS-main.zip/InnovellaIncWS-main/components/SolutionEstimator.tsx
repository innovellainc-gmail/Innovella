'use client';

import React, { useState } from 'react';
import { 
  Calculator, 
  Layers, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  ArrowRight,
  Cpu
} from 'lucide-react';

interface SolutionEstimatorProps {
  onApplyScopeToContact: (scopeData: {
    vertical: string;
    need: string;
    compliance: string[];
    scale: string;
  }) => void;
}

export default function SolutionEstimator({ onApplyScopeToContact }: SolutionEstimatorProps) {
  const [selectedVertical, setSelectedVertical] = useState('retail');
  const [selectedNeed, setSelectedNeed] = useState('integration');
  const [selectedScale, setSelectedScale] = useState('enterprise');
  const [selectedCompliance, setSelectedCompliance] = useState<string[]>(['SOC 2']);

  const verticals = [
    { id: 'retail', label: 'Retail & Omnichannel' },
    { id: 'healthcare', label: 'Healthcare & EHR' },
    { id: 'lifesciences', label: 'Life Sciences & Pharma' },
    { id: 'defense', label: 'Space & Defense' },
    { id: 'construction', label: 'Construction & EPC' },
    { id: 'insurance', label: 'Insurance & Risk SaaS' },
    { id: 'it', label: 'IT & Cloud Infrastructure' },
    { id: 'humanitarian', label: 'Humanitarian & Global NGO' }
  ];

  const needs = [
    { id: 'integration', label: 'Systems Integration & Inntermix™ Middleware', desc: 'Bridge legacy ERPs, mainframes, APIs, and real-time event streams' },
    { id: 'assessment', label: 'Comprehensive IT & Architecture Assessment', desc: 'Full-stack code audit, database profiling, security review, and modernization roadmap' },
    { id: 'custom-dev', label: 'Custom Enterprise Software Engineering', desc: 'Full-lifecycle design, microservices, and web/mobile application delivery' },
    { id: 'compliance', label: 'Regulatory Compliance & System Validation', desc: 'FDA 21 CFR Part 11, GAMP 5, HIPAA, ITAR, or SOC 2 hardening' }
  ];

  const complianceOptions = [
    'FDA 21 CFR Part 11',
    'HIPAA / HITECH',
    'ITAR / NIST 800-171',
    'GAMP 5 (CSV)',
    'SOC 2 Type II',
    'CDISC / SDTM Data Standards',
    'PCI-DSS Level 1'
  ];

  const toggleCompliance = (item: string) => {
    if (selectedCompliance.includes(item)) {
      setSelectedCompliance(selectedCompliance.filter((c) => c !== item));
    } else {
      setSelectedCompliance([...selectedCompliance, item]);
    }
  };

  const getEstimatedTimeline = () => {
    if (selectedNeed === 'assessment') return '3 to 6 Weeks';
    if (selectedScale === 'enterprise') return '12 to 24 Weeks';
    if (selectedScale === 'medium') return '8 to 14 Weeks';
    return '6 to 10 Weeks';
  };

  const handleApply = () => {
    onApplyScopeToContact({
      vertical: verticals.find(v => v.id === selectedVertical)?.label || selectedVertical,
      need: needs.find(n => n.id === selectedNeed)?.label || selectedNeed,
      compliance: selectedCompliance,
      scale: selectedScale
    });
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section 
      id="estimator" 
      className="py-20 bg-white text-slate-900 relative border-b border-slate-200 scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-md mb-3 uppercase tracking-wider">
            Interactive Scoping Tool
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Enterprise Architecture & Engagement Scope Estimator
          </h2>
          <p className="mt-3 text-slate-600 text-base leading-relaxed">
            Configure your organization’s vertical, integration complexity, and regulatory mandates to receive a preliminary architecture roadmap recommendation.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Selectors */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Step 1: Industry Vertical */}
            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
                1. Select Industry Vertical
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {verticals.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => setSelectedVertical(v.id)}
                    className={`p-2.5 rounded-lg text-xs font-bold text-left transition-colors cursor-pointer ${
                      selectedVertical === v.id
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                    }`}
                  >
                    {v.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Primary Engagement Scope */}
            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
                2. Select Primary Architectural Need
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {needs.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => setSelectedNeed(n.id)}
                    className={`p-4 rounded-xl text-left transition-all cursor-pointer ${
                      selectedNeed === n.id
                        ? 'bg-white border-2 border-blue-600 shadow-md'
                        : 'bg-white hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    <div className={`font-bold text-xs mb-1 ${selectedNeed === n.id ? 'text-blue-600' : 'text-slate-900'}`}>{n.label}</div>
                    <div className="text-[11px] text-slate-500 leading-snug">{n.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Regulatory & Compliance Standards */}
            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
                3. Required Regulatory & Compliance Frameworks (Optional)
              </label>
              <div className="flex flex-wrap gap-2">
                {complianceOptions.map((opt) => {
                  const isChecked = selectedCompliance.includes(opt);
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => toggleCompliance(opt)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                        isChecked
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '}
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 4: Scale & Endpoints */}
            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
                4. Systems & Endpoint Scale
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'standard', label: 'Standard Tier', sub: '1 - 5 Endpoints' },
                  { id: 'medium', label: 'Mid-Market', sub: '6 - 25 Endpoints' },
                  { id: 'enterprise', label: 'Enterprise / Global', sub: '26+ Multi-Site Nodes' }
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedScale(s.id)}
                    className={`p-3 rounded-lg text-center transition-colors cursor-pointer ${
                      selectedScale === s.id
                        ? 'bg-blue-600 text-white font-bold shadow-sm'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                    }`}
                  >
                    <div className="text-xs font-bold">{s.label}</div>
                    <div className="text-[10px] opacity-90">{s.sub}</div>
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Blueprint Summary Card */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-xl">
              
              <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
                <span className="text-xs font-bold uppercase text-blue-400 tracking-wider">
                  Engagement Blueprint
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                  Custom Architecture
                </span>
              </div>

              {/* Summary of selections */}
              <div className="space-y-4 mb-6">
                <div>
                  <span className="text-[11px] text-slate-400 uppercase tracking-widest block mb-0.5 font-semibold">
                    Target Vertical & Domain
                  </span>
                  <div className="text-base font-bold text-white">
                    {verticals.find(v => v.id === selectedVertical)?.label}
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 uppercase tracking-widest block mb-0.5 font-semibold">
                    Core Solution Focus
                  </span>
                  <div className="text-sm font-semibold text-blue-300">
                    {needs.find(n => n.id === selectedNeed)?.label}
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 uppercase tracking-widest block mb-1 font-semibold">
                    Compliance & Security Standards
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {selectedCompliance.length > 0 ? (
                      selectedCompliance.map(c => (
                        <span key={c} className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-800 text-emerald-300 border border-emerald-800/60">
                          {c}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-slate-400">Standard Commercial Security</span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-400 block mb-0.5 font-bold">Est. Phase 1 Timeline</span>
                    <span className="text-sm font-extrabold text-blue-400 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-blue-400" />
                      {getEstimatedTimeline()}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-400 block mb-0.5 font-bold">Innovella SLA</span>
                    <span className="text-sm font-extrabold text-emerald-400">
                      99.995% Uptime
                    </span>
                  </div>
                </div>
              </div>

              {/* Recommended Architecture Deliverables */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 mb-6">
                <span className="text-xs font-bold text-white uppercase tracking-wider block mb-2">
                  Included Phase Deliverables:
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Technical Architecture & Interface Specification</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>High-Concurrency Integration & Connector Harness</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Automated Verification & Compliance Audit Package</span>
                  </li>
                </ul>
              </div>

              {/* CTA Transfer to Contact */}
              <button
                id="btn-estimator-apply"
                type="button"
                onClick={handleApply}
                className="w-full py-3.5 px-4 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Apply Parameters to Consultation Request</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
