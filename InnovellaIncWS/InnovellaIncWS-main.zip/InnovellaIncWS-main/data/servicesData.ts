export interface ServiceCapability {
  id: string;
  title: string;
  category: string;
  iconName: string;
  description: string;
  keyDeliverables: string[];
  technologies: string[];
  enterpriseBenefits: string;
}

export const SERVICES_DATA: ServiceCapability[] = [
  {
    id: 'enterprise-integration',
    title: 'Systems Integration & Interoperability',
    category: 'Core Integration',
    iconName: 'Network',
    description: 'Break down legacy data silos with high-throughput middleware, real-time message brokering, and robust API mesh architectures. Powered by custom connectors and our proprietary Inntermix™ integration methodology.',
    keyDeliverables: [
      'Bidirectional real-time and event-driven data integration',
      'Legacy ERP, Mainframe (AS/400), and modern SaaS bridge connectors',
      'High-reliability message queuing with automatic retry and dead-letter pipelines',
      'Enterprise API management, rate limiting, and cryptographic data validation'
    ],
    technologies: ['Inntermix Platform', 'REST & GraphQL APIs', 'RabbitMQ / Kafka', 'Azure Service Bus', 'IBM MQ', 'HL7 / FHIR Gateway'],
    enterpriseBenefits: 'Eliminates batch latency, prevents data duplication, and enables instant cross-departmental business intelligence.'
  },
  {
    id: 'it-architecture-assessments',
    title: 'Enterprise IT & Application Assessments',
    category: 'Strategy & Advisory',
    iconName: 'ShieldCheck',
    description: 'Comprehensive technical evaluations of mission-critical software, database bottlenecks, security postures, code quality, and cloud readiness to de-risk modernization initiatives.',
    keyDeliverables: [
      'Full-stack architecture audit and legacy technical debt quantification',
      'Database performance tuning, indexing analysis, and query profiling',
      'Security vulnerability scans and regulatory compliance gap analysis',
      'Actionable modernization roadmap with ROI and risk mitigation milestones'
    ],
    technologies: ['Static Code Analysis', 'SQL Profiler / Query Tuning', 'Cloud Readiness Frameworks', 'Threat Modeling', 'NIST / OWASP Frameworks'],
    enterpriseBenefits: 'Pinpoints critical vulnerabilities before they cause outages, optimizing infrastructure investments.'
  },
  {
    id: 'custom-software-engineering',
    title: 'Custom Enterprise Software Engineering',
    category: 'Engineering & Development',
    iconName: 'Code2',
    description: 'Full-lifecycle software development of scalable, resilient, and mission-critical web, mobile, and distributed systems tailored to your unique operational workflows.',
    keyDeliverables: [
      'High-concurrency distributed backend microservices',
      'Responsive, accessible, modern web and mobile executive interfaces',
      'Automated testing suites (Unit, Integration, Performance, E2E)',
      'CI/CD deployment pipelines with zero-downtime rolling releases'
    ],
    technologies: ['C# / .NET Core', 'TypeScript / React / Next.js', 'Python / Node.js', 'PostgreSQL / SQL Server', 'Docker / Kubernetes', 'Redis'],
    enterpriseBenefits: 'Proprietary IP tailored exactly to your competitive advantage with zero vendor lock-in.'
  },
  {
    id: 'regulatory-compliance-validation',
    title: 'Life Sciences & Healthcare Compliance (GxP / HIPAA)',
    category: 'Compliance & Validation',
    iconName: 'FileCheck2',
    description: 'Computerized System Validation (CSV) adhering to FDA 21 CFR Part 11, GAMP 5, HIPAA, HITECH, and ISO standards for pharmaceuticals, medical devices, and health networks.',
    keyDeliverables: [
      'Installation, Operational, and Performance Qualification (IQ/OQ/PQ)',
      'Immutable cryptographic audit logging and electronic signature verification',
      'Traceability matrices, validation plans, and SOP documentation',
      'Automated regression suites ensuring ongoing compliance after updates'
    ],
    technologies: ['FDA 21 CFR Part 11', 'GAMP 5 Standards', 'HIPAA Cryptography', 'CDISC / SDTM', 'Audit Trail Engines'],
    enterpriseBenefits: 'Guarantees unshakeable audit readiness, passes regulatory scrutiny, and mitigates compliance penalties.'
  },
  {
    id: 'defense-security-architecture',
    title: 'Defense & Aerospace Zero-Trust Engineering',
    category: 'Defense & Security',
    iconName: 'Lock',
    description: 'ITAR-compliant software engineering and air-gapped data synchronization designed for aerospace defense primes and strict government security requirements.',
    keyDeliverables: [
      'Air-gapped and bandwidth-constrained store-and-forward telemetry',
      'NIST SP 800-171 and CMMC compliant software engineering',
      'Granular Role-Based (RBAC) and Attribute-Based Access Control (ABAC)',
      'Deterministic failover protocols for mission-critical continuity'
    ],
    technologies: ['ITAR Compliance', 'NIST SP 800-171', 'Zero-Trust Frameworks', 'Hardware Security Modules', 'Air-Gapped Sync'],
    enterpriseBenefits: 'Safeguards national security and intellectual property with zero-defect engineering standards.'
  },
  {
    id: 'database-big-data-architecture',
    title: 'High-Volume Database & Big Data Architecture',
    category: 'Data & Analytics',
    iconName: 'Database',
    description: 'Design, optimize, and scale transactional (OLTP) and analytical (OLAP) database clusters handling millions of daily transactions with sub-millisecond response times.',
    keyDeliverables: [
      'High-availability clustering (AlwaysOn, Multi-Region Replicas)',
      'Data warehousing, ETL/ELT pipeline design, and real-time streaming',
      'Sharding, partitioning, and historical archival strategies',
      'Schema refactoring with zero-downtime online migration'
    ],
    technologies: ['SQL Server AlwaysOn', 'PostgreSQL', 'Oracle Enterprise', 'Snowflake / BigQuery', 'Apache Spark', 'Redis Cluster'],
    enterpriseBenefits: 'Prevents database deadlocks, drastically reduces report generation times, and future-proofs data scaling.'
  }
];
