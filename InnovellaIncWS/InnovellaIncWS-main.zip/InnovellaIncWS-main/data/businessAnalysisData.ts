export interface AnalysisSection {
  title: string;
  badge: string;
  summary: string;
  points: { label: string; detail: string; status?: 'resolved' | 'improved' | 'modernized' }[];
}

export const BUSINESS_ANALYSIS_REPORT = {
  title: 'Executive Website Review & Strategic Modernization Analysis',
  subtitle: 'Comprehensive Audit of http://www.innovella.com by Senior Full-Stack Architect & Enterprise Business Analyst',
  date: 'August 2026 Audit Edition',
  author: 'Senior Enterprise Solutions Architect & Lead Business Analyst',
  executiveSummary: `Founded in 2003 in Costa Mesa, California, Innovella, Inc. established itself as a premier technical consulting, custom software development, and IT assessment firm with deep Microsoft and enterprise systems mastery. A core asset in its historical portfolio has been "Inntermix," a proprietary data integration platform engineered to facilitate frictionless data sharing across disparate enterprise systems.

However, the legacy web presence (innovella.com) suffered from outdated information architecture, lack of responsive design, generalized service copy that obscured its monumental client engagements (such as Boeing, Allergan, Fluor, Burlington Coat Factory, and Patagonia), and dated copyright dates. 

This 2026 modernization completely re-architects Innovella's digital flagship into a high-authority, fully responsive enterprise showcase emphasizing its proven track record across 8 strategic verticals and 11 marquee client engagements.`,
  
  auditSections: [
    {
      title: '1. Legacy Information Architecture & UX Deficiencies (Original Website Audit)',
      badge: 'Legacy Pain Points',
      summary: 'Analysis of the original web presence identified severe limitations in positioning, mobile responsiveness, and credibility presentation:',
      points: [
        {
          label: 'Obscured Enterprise Client Roster',
          detail: 'High-profile client engagements (Boeing, Allergan, Parexel, Fluor, Burlington, Patagonia, Pacific Dental Services, Opsware) were either buried or unheralded, failing to capitalize on immense social proof.',
          status: 'resolved'
        },
        {
          label: 'Non-Responsive / Desktop-Centric Layout',
          detail: 'The original site lacked fluid viewport adaptation, resulting in broken layouts, unreadable typography, and horizontal scrolling on smartphones and tablets.',
          status: 'resolved'
        },
        {
          label: 'Undifferentiated Service Messaging',
          detail: 'Services were grouped into generic buckets (Web, Database, Systems) without vertical-specific compliance context (such as FDA 21 CFR Part 11, HIPAA, ITAR, or GAMP 5 validation).',
          status: 'resolved'
        },
        {
          label: 'Outdated Visual Identity & Copyright',
          detail: 'Legacy styling featured low contrast, rigid tables, and expired copyright dates, which undermined credibility with modern enterprise procurement teams.',
          status: 'resolved'
        }
      ]
    },
    {
      title: '2. Strategic Business Analyst Recommendations & Positioning Strategy',
      badge: 'Strategic Growth Pillars',
      summary: 'To position Innovella, Inc. as an elite systems integration and high-reliability software consultancy in 2026, we executed four strategic pivots:',
      points: [
        {
          label: 'Vertical-Driven Positioning Framework',
          detail: 'Structured the firm’s capabilities into 8 distinct industry verticals (Retail, Healthcare, IT, Life Sciences, Insurance, Space & Defense, Construction, Humanitarian Relief) with dedicated case studies and metrics.',
          status: 'improved'
        },
        {
          label: 'Proprietary IP Elevation (Inntermix™ Platform)',
          detail: 'Re-positioned the proprietary Inntermix integration middleware into a modern hybrid-cloud interoperability mesh capable of bridging legacy AS/400 / ERPs with event-driven microservices.',
          status: 'improved'
        },
        {
          label: 'Regulatory & Compliance Authority',
          detail: 'Explicitly highlighted Innovella’s mastery in high-stakes regulatory environments: ITAR / NIST for defense, FDA 21 CFR Part 11 for life sciences, and HIPAA / HITECH for healthcare.',
          status: 'improved'
        },
        {
          label: 'Interactive Engagement Scoping Tool',
          detail: 'Introduced an interactive Solution Estimator allowing enterprise decision-makers to self-assess architectural needs, compliance mandates, and integration complexity before scheduling an executive consultation.',
          status: 'improved'
        }
      ]
    },
    {
      title: '3. Senior Developer Technical Re-Architecture Matrix',
      badge: '2026 Tech Stack',
      summary: 'The 2026 web application was built from the ground up utilizing enterprise-grade frontend standards:',
      points: [
        {
          label: 'Next.js 15 App Router & React 19',
          detail: 'Engineered with strict TypeScript type safety, server/client component boundaries, and high-performance server rendering.',
          status: 'modernized'
        },
        {
          label: 'Tailwind CSS v4 & Sophisticated Dark Canvas',
          detail: 'Replaced dated tables with an executive dark slate palette, mathematically calculated padding, WCAG AA contrast, and zero AI-slop visual discipline.',
          status: 'modernized'
        },
        {
          label: '100% Mobile & Tablet Fluid Responsiveness',
          detail: 'Configured mobile navigation drawers, touch targets >44px, flexible flex/grid layouts, and responsive typography scaling smoothly from 320px mobile to 4K displays.',
          status: 'modernized'
        },
        {
          label: 'Granular Search & Interactive Filtering',
          detail: 'Instant client search, vertical tab switching, and comprehensive modal deep-dives with zero page reloads.',
          status: 'modernized'
        },
        {
          label: 'Strict Copyright & Grammar Validation',
          detail: 'Standardized all copyright notices to reflect 2003–2026, audited every sentence for flawless grammar, and eliminated colloquialisms.',
          status: 'modernized'
        }
      ]
    }
  ]
};
