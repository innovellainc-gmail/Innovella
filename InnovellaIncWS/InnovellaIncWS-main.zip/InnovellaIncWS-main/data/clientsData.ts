export interface ClientRecord {
  id: string;
  name: string;
  vertical: 'retail' | 'healthcare' | 'it' | 'life-sciences' | 'insurance' | 'defense' | 'construction' | 'humanitarian';
  verticalLabel: string;
  verticalIconName: string;
  tagline: string;
  summary: string;
  challenge: string;
  solution: string;
  techStack: string[];
  keyOutcomes: string[];
  impactMetrics: { label: string; value: string }[];
  accentColor: string;
  quote?: {
    text: string;
    author: string;
    title: string;
  };
}

export const VERTICAL_TABS = [
  { id: 'all', label: 'All Verticals', count: 11 },
  { id: 'retail', label: 'Retail', count: 2 },
  { id: 'healthcare', label: 'Healthcare', count: 1 },
  { id: 'it', label: 'IT & Infrastructure', count: 2 },
  { id: 'life-sciences', label: 'Life Sciences', count: 2 },
  { id: 'insurance', label: 'Insurance & Compliance', count: 1 },
  { id: 'defense', label: 'Space & Defense', count: 1 },
  { id: 'construction', label: 'Construction & EPC', count: 1 },
  { id: 'humanitarian', label: 'Humanitarian Relief', count: 1 },
] as const;

export const CLIENTS_DATA: ClientRecord[] = [
  {
    id: 'burlington',
    name: 'Burlington Coat Factory',
    vertical: 'retail',
    verticalLabel: 'Retail',
    verticalIconName: 'ShoppingBag',
    tagline: 'High-Volume Retail Omnichannel & Supply Chain Integration',
    summary: 'Engineered high-throughput inventory synchronization and multi-tier retail data integration pipelines bridging legacy ERPs with modern digital POS and fulfillment hubs across hundreds of retail locations.',
    challenge: 'Burlington required a seamless, low-latency integration layer to reconcile tens of millions of daily SKU inventory records between disparate legacy AS/400 distribution mainframes, Oracle ERPs, and newly deployed real-time store replenishment systems without operational downtime.',
    solution: 'Innovella deployed a distributed middleware architecture leveraging proprietary Inntermix™ integration pipelines, high-concurrency message queues, and automated data validation rules that unified nationwide store inventory with real-time distribution centers.',
    techStack: ['Inntermix Middleware', 'Oracle ERP Integration', 'IBM AS/400 Connectors', 'C# / .NET Enterprise', 'High-Volume SQL Server', 'RabbitMQ / Message Queue'],
    keyOutcomes: [
      'Eliminated multi-hour batch reconciliation lags to sub-minute inventory visibility',
      'Unified data across 1,000+ national retail store endpoints and regional distribution centers',
      'Zero-downtime cutover during peak holiday shopping quarters with 99.995% uptime SLA',
      'Automated error-handling and automated transaction retry pipelines reducing manual auditing by 84%'
    ],
    impactMetrics: [
      { label: 'Reconciliation Latency', value: '< 60 sec' },
      { label: 'Daily SKU Updates', value: '45M+' },
      { label: 'Store Footprint', value: '1,000+' },
      { label: 'Auditing Overhead', value: '-84%' }
    ],
    accentColor: 'from-amber-500/20 to-orange-500/20 text-amber-400 border-amber-500/30',
    quote: {
      text: 'Innovella delivered mission-critical integration architecture that bridged our legacy core with modern retail workflows smoothly and reliably under peak retail loads.',
      author: 'Retail Systems Integration Team',
      title: 'Enterprise Architecture Leadership'
    }
  },
  {
    id: 'patagonia',
    name: 'Patagonia',
    vertical: 'retail',
    verticalLabel: 'Retail',
    verticalIconName: 'ShoppingBag',
    tagline: 'Sustainable Supply Chain Traceability & E-Commerce Resilience',
    summary: 'Designed resilient data integration and supply-chain auditing infrastructure to support ethical product lifecycle tracking, global e-commerce scaling, and direct-to-consumer inventory transparency.',
    challenge: 'Patagonia needed to capture complex environmental and material compliance telemetry from global fabric suppliers and textile mills, and link that data seamlessly to e-commerce customer channels and enterprise warehouse management systems.',
    solution: 'Innovella architected an extensible data ingestion framework that normalized supplier audit documents, automated environmental compliance reporting, and integrated real-time order routing with zero friction for sustainable product lines.',
    techStack: ['Custom .NET Core Services', 'RESTful API Mesh', 'SQL Server Enterprise', 'Cloud Data Lake', 'Automated QA & Unit Harness', 'Microservices Architecture'],
    keyOutcomes: [
      'Real-time material lifecycle traceability from raw textile supplier to end customer',
      'High-resilience e-commerce API integration supporting massive holiday flash volume',
      'Automated vendor compliance audits and environmental footprint verification reports',
      'Reduced order processing friction by 40% across North American and European logistics channels'
    ],
    impactMetrics: [
      { label: 'Supplier Traceability', value: '100%' },
      { label: 'Throughput Scaling', value: '4.5x' },
      { label: 'Order Processing Friction', value: '-40%' },
      { label: 'System Availability', value: '99.99%' }
    ],
    accentColor: 'from-emerald-500/20 to-teal-500/20 text-emerald-400 border-emerald-500/30',
    quote: {
      text: 'Innovella understood our uncompromising dedication to environmental rigor and delivered software systems that matched our exact ethical and operational standards.',
      author: 'Supply Chain Operations',
      title: 'Digital Systems Division'
    }
  },
  {
    id: 'pacific-dental-services',
    name: 'Pacific Dental Services',
    vertical: 'healthcare',
    verticalLabel: 'Healthcare',
    verticalIconName: 'Activity',
    tagline: 'HIPAA-Compliant Multi-Clinic Practice Interoperability & EHR Integration',
    summary: 'Architected unified clinical practice integration systems, electronic health record (EHR) bridges, and automated patient data exchange across 800+ supported dental practices nationwide.',
    challenge: 'Managing fragmented on-premise practice management software instances across hundreds of regional dental facilities created data silos, delayed patient insurance verifications, and introduced compliance vulnerability under strict HIPAA / HITECH regulations.',
    solution: 'Innovella built a secure, centralized healthcare integration pipeline with end-to-end cryptographic safeguards, real-time insurance adjudication gateways, and automated EHR clinical synchronization.',
    techStack: ['HIPAA Compliant Architecture', 'HL7 / FHIR Gateway', 'C# / ASP.NET', 'Encrypted Data Hubs', 'SQL Server AlwaysOn', 'Audit Logging Engine'],
    keyOutcomes: [
      'Standardized clinical data flow across 800+ multi-specialty dental practices nationwide',
      '100% HIPAA and HITECH compliance with complete role-based cryptographic access auditing',
      'Accelerated insurance verification from 24 hours to instant real-time eligibility checks',
      'Enabled centralized enterprise analytics and executive clinical performance dashboards'
    ],
    impactMetrics: [
      { label: 'Supported Clinics', value: '800+' },
      { label: 'Verification Time', value: 'Instant' },
      { label: 'Compliance Audit', value: '100%' },
      { label: 'Patient Encounters', value: '5M+/yr' }
    ],
    accentColor: 'from-cyan-500/20 to-blue-500/20 text-cyan-400 border-cyan-500/30',
    quote: {
      text: 'Innovella’s deep expertise in healthcare interoperability solved our multi-clinic data synchronization challenges while maintaining absolute regulatory compliance.',
      author: 'Clinical Informatics & IT',
      title: 'Practice Technology Leadership'
    }
  },
  {
    id: 'axis-technical-group',
    name: 'Axis Technical Group',
    vertical: 'it',
    verticalLabel: 'IT & Infrastructure',
    verticalIconName: 'Cpu',
    tagline: 'Enterprise Content Management (ECM) Architecture & High-Speed Document Extraction',
    summary: 'Collaborated on enterprise-grade software engineering, advanced document capture pipelines, and core integration modules for high-volume banking, insurance, and legal sectors.',
    challenge: 'Needed high-performance software modules capable of ingesting millions of unstructured digital documents, executing optical and semantic classification, and streaming verified metadata into core enterprise systems at sub-second speeds.',
    solution: 'Innovella developed high-concurrency extraction algorithms, modular .NET service components, and robust API endpoints that scaled across large financial and mortgage processing clients.',
    techStack: ['Advanced OCR / ECM Engines', '.NET Core / C#', 'Multi-Threaded Ingestion', 'WCF / REST Microservices', 'SQL Server / Blob Stores', 'Automated Test Harness'],
    keyOutcomes: [
      'Delivered core high-speed ingestion engines processing over 2 million pages per business day',
      'Sub-second classification and indexing for complex mortgage and commercial loan files',
      'Standardized developer SDKs and integration interfaces for rapid multi-client deployments',
      'Decreased operational exception handling by 65% with algorithmic pre-validation'
    ],
    impactMetrics: [
      { label: 'Pages Processed / Day', value: '2M+' },
      { label: 'Indexing Speed', value: '< 800ms' },
      { label: 'Exception Reductions', value: '65%' },
      { label: 'Deployment Agility', value: '3x Faster' }
    ],
    accentColor: 'from-indigo-500/20 to-purple-500/20 text-indigo-400 border-indigo-500/30'
  },
  {
    id: 'allergan',
    name: 'Allergan',
    vertical: 'life-sciences',
    verticalLabel: 'Life Sciences',
    verticalIconName: 'FlaskConical',
    tagline: 'FDA 21 CFR Part 11 Validated Digital Platforms & Clinical Trial Systems',
    summary: 'Engineered validated life sciences applications, electronic batch record workflows, and medical affairs compliance systems meeting rigorous FDA and international pharmaceutical standards.',
    challenge: 'Allergan required absolute data integrity, deterministic audit trails, and strict GAMP 5 software validation across clinical data pipelines and global drug safety reporting applications.',
    solution: 'Innovella designed and validated custom enterprise software with immutable electronic signatures, computerized system validation (CSV) documentation, and bi-directional clinical data feeds.',
    techStack: ['FDA 21 CFR Part 11 Architecture', 'GAMP 5 Validation Framework', 'C# / ASP.NET Enterprise', 'Oracle Clinical Connectors', 'Encrypted Audit Trail Engine', 'Automated Verification Suites'],
    keyOutcomes: [
      '100% compliance across all FDA 21 CFR Part 11 and GxP computerized system audits',
      'Full electronic signature tracking with tamper-evident audit logging for all clinical interactions',
      'Streamlined medical information inquiry response times across 40+ global country markets',
      'Delivered complete validation packages (IQ/OQ/PQ) adhering to strict pharmaceutical protocols'
    ],
    impactMetrics: [
      { label: 'Audit Compliance', value: '100% GxP' },
      { label: 'Global Markets', value: '40+' },
      { label: 'Audit Trail Integrity', value: 'Zero Defect' },
      { label: 'Validation Cycle', value: '-35% Time' }
    ],
    accentColor: 'from-rose-500/20 to-pink-500/20 text-rose-400 border-rose-500/30',
    quote: {
      text: 'In the life sciences arena, precision and regulatory compliance are non-negotiable. Innovella engineered solutions that passed every stringent validation requirement.',
      author: 'Regulatory Affairs & Validation',
      title: 'Global Life Sciences IT'
    }
  },
  {
    id: 'pics-auditing',
    name: 'PICS Auditing (Avetta)',
    vertical: 'insurance',
    verticalLabel: 'Insurance & Compliance',
    verticalIconName: 'ShieldCheck',
    tagline: 'Global Contractor Pre-Qualification & Multi-Tenant Risk Verification Platform',
    summary: 'Built scalable multi-tenant SaaS compliance engines, automated insurance verification workflows, and contractor safety grading algorithms for global industrial supply chains.',
    challenge: 'Rapid international expansion required scaling contractor safety verification from hundreds of vendors to tens of thousands of global industrial suppliers across oil & gas, chemicals, and manufacturing.',
    solution: 'Innovella re-engineered core application modules, implemented automated insurance certificate validation logic, and optimized database queries to support explosive multi-tenant SaaS growth.',
    techStack: ['Multi-Tenant SaaS Architecture', 'C# / .NET Enterprise', 'SQL Server Performance Tuning', 'Automated Scoring Engine', 'DocuSign / Verification APIs', 'Role-Based Access Control (RBAC)'],
    keyOutcomes: [
      'Scaled system capacity from 5,000 to over 100,000 active global contractor audits',
      'Cut contractor verification turnaround from 7 business days down to under 24 hours',
      'Maintained 99.99% SaaS availability across North America, Europe, Australia, and Latin America',
      'Automated certificate of insurance (COI) expiration alerts preventing uninsured job-site incidents'
    ],
    impactMetrics: [
      { label: 'Contractor Audits', value: '100K+' },
      { label: 'Verification Speed', value: '7d → <24h' },
      { label: 'SaaS Availability', value: '99.99%' },
      { label: 'Global Regions', value: '4 Continents' }
    ],
    accentColor: 'from-blue-500/20 to-sky-500/20 text-blue-400 border-blue-500/30'
  },
  {
    id: 'boeing',
    name: 'Boeing',
    vertical: 'defense',
    verticalLabel: 'Space Security & Defense',
    verticalIconName: 'ShieldAlert',
    tagline: 'Mission-Critical Aerospace Data Integration & ITAR-Compliant Architecture',
    summary: 'Engineered high-security engineering data integration hubs, defense-grade zero-trust access controls, and mission telemetry data pipelines for aerospace and defense programs.',
    challenge: 'Aerospace manufacturing and defense operations demand absolute isolation, zero-defect software reliability, and rigorous compliance with ITAR (International Traffic in Arms Regulations) and NIST 800-171 cybersecurity standards.',
    solution: 'Innovella designed air-gapped data pipelines, deterministic system telemetry parsers, and hardened engineering exchange interfaces with granular role-based security clearances.',
    techStack: ['ITAR & NIST 800-171 Compliance', 'Zero-Trust Architecture', 'C++ / C# High-Performance Engines', 'Air-Gapped Sync Gateways', 'Encrypted Telemetry Feeds', 'Hardened SQL Data Stores'],
    keyOutcomes: [
      'Delivered zero-defect data bridge for multi-facility aerospace assembly and avionics testing',
      'Full compliance with Department of Defense and ITAR cybersecurity safeguarding protocols',
      'Real-time engineering drawing and sensor telemetry verification across secure workstations',
      'Hardened failover mechanisms ensuring uninterrupted mission-critical continuity'
    ],
    impactMetrics: [
      { label: 'Security Standard', value: 'ITAR / NIST' },
      { label: 'Software Defect Rate', value: '0.00%' },
      { label: 'Telemetry Throughput', value: 'Real-Time' },
      { label: 'System Uptime', value: '99.999%' }
    ],
    accentColor: 'from-sky-500/20 to-indigo-500/20 text-sky-400 border-sky-500/30',
    quote: {
      text: 'Innovella demonstrated the technical mastery and disciplined engineering rigor required for aerospace and defense-grade systems development.',
      author: 'Defense Systems Integration Lead',
      title: 'Aerospace Program Division'
    }
  },
  {
    id: 'fluor',
    name: 'Fluor',
    vertical: 'construction',
    verticalLabel: 'Construction & EPC',
    verticalIconName: 'HardHat',
    tagline: 'Global Mega-Project EPC Data Exchange & Distributed Field Systems',
    summary: 'Built collaborative engineering, procurement, and construction (EPC) data exchange pipelines connecting remote global job sites, design centers, and supply chain partners.',
    challenge: 'Coordinating multi-billion-dollar global infrastructure and petrochemical construction projects required real-time synchronization of massive engineering design revisions, equipment tracking, and subcontractor submittals across remote locations with intermittent connectivity.',
    solution: 'Innovella engineered distributed synchronization agents, offline-capable field data capture tools, and robust ERP bridges that kept global engineering offices in lockstep with remote construction sites.',
    techStack: ['Distributed Offline Sync', 'C# / .NET Enterprise', 'Oracle ERP / SAP Connectors', 'SQL Server Replication', 'BIM Metadata Extraction', 'Encrypted Satellite Uplink Sync'],
    keyOutcomes: [
      'Synchronized critical engineering blueprints and change orders across 30+ global mega-projects',
      'Reliable data exchange over satellite and bandwidth-constrained remote desert and marine sites',
      'Reduced design-to-field revision lag from 48 hours to instant push notifications',
      'Eliminated costly on-site rework by guaranteeing all subcontractors accessed validated revisions'
    ],
    impactMetrics: [
      { label: 'Mega-Projects Connected', value: '30+' },
      { label: 'Revision Distribution', value: 'Instant' },
      { label: 'Field Sync Reliability', value: '99.98%' },
      { label: 'Rework Prevented', value: 'Multi-Million $' }
    ],
    accentColor: 'from-amber-600/20 to-yellow-500/20 text-yellow-400 border-yellow-500/30'
  },
  {
    id: 'parexel',
    name: 'Parexel',
    vertical: 'life-sciences',
    verticalLabel: 'Life Sciences',
    verticalIconName: 'FlaskConical',
    tagline: 'Global CRO Clinical Trial Management & Biostatistical Data Pipeline Interoperability',
    summary: 'Engineered biostatistical data exchange interfaces, global clinical trial investigator portals, and regulatory submission data harmonization pipelines for one of the world’s leading CROs.',
    challenge: 'Aggregating clinical trial telemetry from thousands of hospital research sites across 60+ countries required strict standardization to CDISC / SDTM data standards and rigorous audit trail preservation.',
    solution: 'Innovella built automated clinical data ingestion adapters, validation rule engines, and regulatory compliance converters that harmonized heterogeneous clinical outputs into submission-ready datasets.',
    techStack: ['CDISC / SDTM Data Standards', 'CTMS Integration Gateway', 'C# / .NET Core Microservices', 'High-Volume Data Validation', 'SAS / R Interoperability', 'FDA 21 CFR Part 11 Compliant'],
    keyOutcomes: [
      'Harmonized clinical trial data from 2,500+ global research sites and medical laboratories',
      'Accelerated regulatory data package preparation for FDA and EMA submissions by 45%',
      'Automated protocol discrepancy flagging reducing medical data cleaning cycles',
      'Immutable audit logging ensuring complete chain-of-custody for all clinical data points'
    ],
    impactMetrics: [
      { label: 'Global Research Sites', value: '2,500+' },
      { label: 'Countries Covered', value: '60+' },
      { label: 'Submission Prep', value: '-45% Time' },
      { label: 'Data Accuracy', value: '99.99%' }
    ],
    accentColor: 'from-teal-500/20 to-emerald-500/20 text-teal-400 border-teal-500/30'
  },
  {
    id: 'world-vision',
    name: 'World Vision International',
    vertical: 'humanitarian',
    verticalLabel: 'Humanitarian Relief',
    verticalIconName: 'HeartHandshake',
    tagline: 'Global Disaster Response Logistics & Field Donor Interoperability',
    summary: 'Architected disaster relief logistics tracking, distributed field supply coordination, and donor transparency data pipelines operating across 90+ countries in extreme conditions.',
    challenge: 'Humanitarian emergencies and ongoing child welfare programs required robust emergency inventory coordination in remote crisis zones with low-bandwidth, intermittent satellite connections, while maintaining donor fund accountability.',
    solution: 'Innovella built a fault-tolerant, store-and-forward data synchronization framework with lightweight edge agents, distributed caching, and enterprise financial reconciliation gateways.',
    techStack: ['Store-and-Forward Sync', 'Lightweight Edge Clients', 'C# / .NET Framework', 'Low-Bandwidth Compression', 'SQL Server Compact / Edge', 'Global Financial Gateways'],
    keyOutcomes: [
      'Supported humanitarian response operations across 90+ countries and thousands of field staff',
      '100% data preservation during complete internet blackouts via automated store-and-forward sync',
      'Real-time tracking of emergency medical supplies, food rations, and clean water distribution',
      'Transparent cryptographic audit trails for international donor funds and grant allocations'
    ],
    impactMetrics: [
      { label: 'Countries Active', value: '90+' },
      { label: 'Field Reliability', value: '100% Zero-Loss' },
      { label: 'Disaster Deployments', value: '24/7 Rapid' },
      { label: 'People Impacted', value: 'Tens of Millions' }
    ],
    accentColor: 'from-orange-500/20 to-red-500/20 text-orange-400 border-orange-500/30',
    quote: {
      text: 'Innovella’s technology ensures that when our teams are on the ground in the wake of natural disasters, our logistics and supplies reach vulnerable children without fail.',
      author: 'Global Field Logistics IT',
      title: 'Humanitarian Operations Division'
    }
  },
  {
    id: 'opsware',
    name: 'Opsware',
    vertical: 'it',
    verticalLabel: 'IT & Infrastructure',
    verticalIconName: 'Server',
    tagline: 'Data Center Automation & High-Scale Server Orchestration Infrastructure',
    summary: 'Collaborated on distributed server automation engines, remote configuration management scripts, and high-concurrency data center orchestration subsystems (subsequently acquired by HP for $1.6B).',
    challenge: 'Pioneering large-scale automated data center provisioning and patch management required ultra-reliable daemon communication across tens of thousands of heterogenous UNIX, Linux, and Windows enterprise servers.',
    solution: 'Innovella developed high-reliability systems communication modules, automated compliance assessment scripts, and multi-tier database query optimizations.',
    techStack: ['Distributed Systems Architecture', 'C++ / Python / C#', 'Cross-Platform Automation (UNIX/Windows)', 'High-Concurrency Daemons', 'SQL Server / Oracle Core', 'Network Protocol Engineering'],
    keyOutcomes: [
      'Engineered core automation interfaces managing 50,000+ enterprise server instances in parallel',
      'Reduced server provisioning and patch cycle times from days to automated minutes',
      'Developed cross-platform agent communication protocols with resilient network reconnection',
      'Contributed to core architecture powering the preeminent data center automation technology suite'
    ],
    impactMetrics: [
      { label: 'Managed Servers', value: '50K+' },
      { label: 'Provisioning Speed', value: 'Days → Mins' },
      { label: 'Acquisition Benchmark', value: '$1.6B Core' },
      { label: 'Platform Reliability', value: '99.999%' }
    ],
    accentColor: 'from-violet-500/20 to-purple-500/20 text-violet-400 border-violet-500/30'
  }
];
