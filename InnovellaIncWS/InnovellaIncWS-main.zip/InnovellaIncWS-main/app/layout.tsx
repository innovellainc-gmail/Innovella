import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Innovella, Inc. | Enterprise Technology Consulting & Systems Integration',
  description: 'Enterprise consulting, systems integration, and custom software engineering. Trusted by Fortune 500, healthcare innovators, defense primes, and global enterprises.',
  openGraph: {
    title: 'Innovella, Inc. | Enterprise Technology Consulting',
    description: 'Specialized enterprise consulting, systems interoperability, and custom engineering across Retail, Healthcare, Life Sciences, Space & Defense, and IT.',
    type: 'website',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="bg-white text-slate-900 antialiased font-sans selection:bg-blue-600/20 selection:text-blue-900" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
