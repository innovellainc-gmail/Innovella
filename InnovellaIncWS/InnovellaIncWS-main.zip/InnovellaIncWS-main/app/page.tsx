'use client';

import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import ClientShowcase from '../components/ClientShowcase';
import InntermixArchitecture from '../components/InntermixArchitecture';
import ServicesSection from '../components/ServicesSection';
import BusinessAnalysisReport from '../components/BusinessAnalysisReport';
import SolutionEstimator from '../components/SolutionEstimator';
import AboutHeritage from '../components/AboutHeritage';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

export default function HomePage() {
  const [activeVertical, setActiveVertical] = useState<string>('all');
  const [appliedScope, setAppliedScope] = useState<{
    vertical: string;
    need: string;
    compliance: string[];
    scale: string;
  } | null>(null);

  const handleApplyScope = (scopeData: {
    vertical: string;
    need: string;
    compliance: string[];
    scale: string;
  }) => {
    setAppliedScope(scopeData);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Sticky Header Navigation */}
      <Navbar />

      {/* Main Page Sections */}
      <main className="flex-grow">
        {/* Hero Section with Quick Vertical Switchers & Live Stats */}
        <Hero 
          onSelectVertical={(verticalId) => setActiveVertical(verticalId)} 
        />

        {/* Featured Clients & Verticals Portfolio Showcase */}
        <ClientShowcase 
          activeVertical={activeVertical}
          onSelectVertical={(verticalId) => setActiveVertical(verticalId)}
        />

        {/* Inntermix™ Enterprise Interoperability & Data Integration Architecture */}
        <InntermixArchitecture />

        {/* Core Enterprise Capabilities & Specialized Domains */}
        <ServicesSection />

        {/* Senior Business Analyst & Developer Strategic Audit of innovella.com */}
        <BusinessAnalysisReport />

        {/* Interactive Architecture & Engagement Scope Estimator */}
        <SolutionEstimator 
          onApplyScopeToContact={handleApplyScope}
        />

        {/* Company Heritage & 20+ Year Track Record */}
        <AboutHeritage />

        {/* Executive Consultation & RFP Intake Form */}
        <ContactSection 
          initialVertical={appliedScope?.vertical}
          initialNeed={appliedScope?.need}
        />
      </main>

      {/* 2026 Enterprise Footer */}
      <Footer 
        onSelectVertical={(verticalId) => setActiveVertical(verticalId)}
      />
    </div>
  );
}
