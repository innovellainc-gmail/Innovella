'use client';

import React from 'react';
import { 
  MapPin, 
  Mail, 
  ShieldCheck, 
  ArrowUp
} from 'lucide-react';
import { VERTICAL_TABS, CLIENTS_DATA } from '../data/clientsData';

interface FooterProps {
  onSelectVertical: (verticalId: string) => void;
}

export default function Footer({ onSelectVertical }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-white text-slate-600 border-t border-slate-200 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Col 1: Brand & Headquarters */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-black text-sm">
                I
              </div>
              <span className="font-extrabold text-slate-900 tracking-tight text-xl">
                INNOVELLA<span className="text-blue-600">, INC.</span>
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
              Specialized enterprise technology consulting, high-throughput systems integration (Inntermix™), IT architecture assessments, and custom software development. Serving industry leaders since 2003.
            </p>

            <div className="space-y-2 pt-2 text-xs">
              <div className="flex items-center gap-2 text-slate-700">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Costa Mesa, California, USA</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                <a href="mailto:info@innovella.com" className="hover:text-blue-600 transition-colors">info@innovella.com</a>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>FDA 21 CFR Part 11 &bull; HIPAA &bull; ITAR Compliant Delivery</span>
              </div>
            </div>
          </div>

          {/* Col 2: Industry Verticals */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Industry Verticals
            </h4>
            <ul className="space-y-2 text-xs">
              {VERTICAL_TABS.filter(t => t.id !== 'all').map((tab) => (
                <li key={tab.id}>
                  <button
                    type="button"
                    onClick={() => {
                      onSelectVertical(tab.id);
                      const el = document.getElementById('clients');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-slate-600 hover:text-blue-600 transition-colors text-left cursor-pointer"
                  >
                    {tab.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Marquee Client Roster */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Featured Clients
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600">
              {CLIENTS_DATA.map((client) => (
                <li key={client.id} className="hover:text-blue-600 transition-colors">
                  <a href="#clients">
                    {client.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Quick Navigation & Legal */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li>
                <a href="#hero-section" className="hover:text-blue-600 transition-colors">
                  Overview
                </a>
              </li>
              <li>
                <a href="#clients" className="hover:text-blue-600 transition-colors">
                  Client Case Studies
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-blue-600 transition-colors">
                  Core Capabilities
                </a>
              </li>
              <li>
                <a href="#inntermix" className="hover:text-blue-600 transition-colors">
                  Inntermix™ Platform
                </a>
              </li>
              <li>
                <a href="#analysis" className="hover:text-blue-600 transition-colors">
                  Strategic Website Audit
                </a>
              </li>
              <li>
                <a href="#estimator" className="hover:text-blue-600 transition-colors">
                  Scope Estimator
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-blue-600 transition-colors">
                  Executive Consultation
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Copyright 2026 and Back to top */}
        <div className="pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-center sm:text-left">
            <span className="text-slate-700 font-medium">
              &copy; 2003&ndash;2026 Innovella, Inc. All rights reserved.
            </span>
            <span className="hidden sm:inline">&bull;</span>
            <span>Costa Mesa, CA, USA</span>
            <span className="hidden sm:inline">&bull;</span>
            <span>Inntermix™ is a registered trademark of Innovella, Inc.</span>
          </div>

          <button
            id="footer-scroll-top-btn"
            type="button"
            onClick={scrollToTop}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors border border-slate-300 text-xs font-semibold cursor-pointer"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
